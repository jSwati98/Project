/* The program myDCT.c  takes a PGM image fie as an input. According to the x-size and y-size given in the PGM file, 
myDCT program dynamically creates an array to hold the input matrix from the PGM file. Then myDCT program divides 
the entire matrix into 16 x 16 macro block and each 16 x 16 macro block into four 8 x 8 block. Each 8 x 8 block 
undergoes a DCT tranform, and then it gets divided by quantization matrix and qscale. Then rounding, cropping 
and offsetting is performed on this 8 x 8 block and the result is written to an output DCTfile. The entire steps 
of division into 16 x 16 macroblock and to 8 x 8 blocks continues until it read all the values in the input matrix. */

#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define PI 3.14159265358979323846
double dct(int u,int v,int mat[8][8]);
void calDCT(int mat[8][8], FILE *f1p);
int quantcoeff[8][8];
float qt[8][8];
float qScale;
int main(int argc, char *argv[]) 
{
	// Declarations of variables
	FILE *fp;
	int c,*p;
	int a[16][16];
	int row, col, maxValue,qCoef,k,l,m,n,ro,co,x,y,i,aPtr,row1,col1,row2,col2,itr;
	int j1 = 0;
	int **original;
	int index= 0;
	int one[8][8],two[8][8],three[8][8],four[8][8];
	int j= 0;
	int printValX=0x0;
	int printValY=0x0;
	char name[10],str[3];
	char space = '\n';
	FILE *f1p, *ofp;
	// End of declarations

	fp = fopen(argv[1], "r");   
	ofp=fopen(argv[2],"r");    

	//reading the quantization matrix
	for(qCoef=0;qCoef<8;qCoef++)
	{
		for(j1=0;j1<8;j1++)
		{
			fscanf(ofp,"%f",&qt[qCoef][j1]);
		}
	}
	qScale = atof(argv[3]);            
	f1p = fopen(argv[4], "w");         
	fscanf(fp, "%s", str);              // Reading P5 from inputfile.pgm
	fscanf(fp, "%d %d", &col, &row);    // Reading rows and columns from inputfile.pgm
	fscanf(fp, "%d", &maxValue);        // Reading MaxValue(255) from inputfile.pgm
	fprintf(f1p,"MYDCT\n");
	fprintf(f1p,"%d %d\n", col, row);
	fprintf(f1p,"%f\n", qScale);
	original = (int **)malloc(row * sizeof(int *));    
	for (i=0; i<row; i++)
	    original[i] = (int *)malloc(col * sizeof(int));

	i = 0;
	j = 0;
    
	//reading the matrix value from the input to an array
	while ((c =fgetc(fp)) != EOF)                  
	{
		unsigned char ch = (unsigned char) c;
		if (ch == '\n')
			continue;
		original[i][j]=ch;
		j++;
		if (j == col) 
		{
			i++;
			j = 0;
		}
	}
	fclose(fp);

	i = 0;
	j = 0;
	
	//Dividing the input image into 16 X 16 macro block
	for(m = 0; m < row; m=m+16)
	{
		for(n = 0 ; n < col; n=n+16)
		{
			for(ro = m; ro < m+16; ro++)
			{
				for(co = n; co < n+16; co++)
				{
					a[ro%16][co%16] = original[ro][co];
				}
			}
    //Dividing 16 X 16 macro block into four 8 x 8 block
			for(row1 = 0; row1 < 8; row1++)
			{
				for(col1 = 0; col1 < 8; col1++)
				{
					one[row1][col1] = a[row1][col1];
					two[row1][col1] = a[row1][col1+8];
					three[row1][col1] = a[row1+8][col1];
					four[row1][col1] = a[row1+8][col1+8];
				}
			}
            //Outputting the coordinates for the 8 x 8 block with respect to input image
			for(itr = 0; itr < 4; itr++)
			{
				if(itr == 0)
				{
					printValX= n;
					printValY= m;
					fprintf(f1p, "%d %d\n",printValX,printValY);
				}
				else if(itr == 1)
				{
					printValX= n+8;
					printValY= m;
					fprintf(f1p, "%d %d\n",printValX,printValY);
				}
				else if(itr == 2)
				{
					printValX= n;
					printValY= m+8;
					fprintf(f1p, "%d %d\n",printValX,printValY);
				}
				else
				{
					printValX= n+8;
					printValY= m+8;
					fprintf(f1p, "%d %d\n",printValX,printValY);
				}
				//Calling the dct function for each of the 8 x 8 block
				if(itr == 0)
					calDCT(one, f1p);
				else if(itr == 1)
					calDCT(two, f1p);
				else if(itr == 2)
					calDCT(three, f1p);
				else
					calDCT(four, f1p);
			}
		}
	}
	fclose(f1p);
	return 0;
}

//The folowing function peforms summations inside DCT formula
double dct(int u, int v, int mat[8][8])
{
	int i, j;
	double matvalue=0.0;
	for(i=0;i<8;i++)
	{
		for(j=0;j<8;j++)
		{
			matvalue+=mat[i][j]*cos((float)((2*i)+1)*u*PI/16.0)*cos((float)((2*j)+1)*v*PI/16.0);
		}
	}
	return(matvalue);
}

//function to evaluate dct for 8 x 8 block
void calDCT(int mat[8][8], FILE *f1p)
{
	int u, v, i, j;
	float coeff;
	double Cu, Cv; 
	double  dctValue = 0.0;
	char space = '\n';
	double F[8][8];
	for(u=0;u<8;u++)
	{
		for(v=0;v<8;v++)
		{
			dctValue=dct(u,v,mat)/4;
			//evaluating Cu and Cv values
			Cu=1;
			Cv=1;
			if(u==0)
				Cu=(1/sqrt(2));
			if(v==0)
				Cv=(1/sqrt(2));
			F[u][v]=(Cu*Cv*dctValue);
		}
	}
    //following code is to multiplying the 8 x 8 block by quantization matrix and qscale, rounding, cropping ad offsetting
	for(i=0;i<8;i++)
	{
		for(j=0;j<8;j++)
		{
			coeff=F[i][j]/(qt[i][j]*qScale);      
			quantcoeff[i][j]=(int)round(coeff);
			if(quantcoeff[i][j] > 128)
			{
				quantcoeff[i][j] = 128;
			}
			else if(quantcoeff[i][j] < -127)
			{
				quantcoeff[i][j] = -127;
			}
			quantcoeff[i][j]+=127;
			fprintf(f1p, "%5d", quantcoeff[i][j]);
		}
		fprintf(f1p, "\n");
	}
}
