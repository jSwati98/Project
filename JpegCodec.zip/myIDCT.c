/* The program myIDCT.c  takes a DCT fie as an input. According to the x-size and y-size 
given in the DCT file, myIDCT program takes 8X8 matrix from the DCT file. Then program 
performs offsetting, quantization and IDCT on each 8X8 matrix thereafter all the 8X8 matrices
are arranged in a rowXcol matrix which is written to  an output .pgm file byte by byte. */
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#define PI 3.14159265358979323846
double idct(int u,int v,double mat[8][8]);
void calIDCT(double mat[8][8],int f[8][8]);
float qt[8][8];
float quantValue;
int main(int argc, char *argv[])
{

	// Declarations of variables
	FILE *fp,*ifp,*ofp;
	int **output;
	int col,row,matcol,matrow,i,j;
	int qCoef,j1;
	int mat_temp;
	char line[300];
	char str[10];
	double mat[8][8];
	int f[8][8];
	double values[8][8];

	fp=fopen(argv[1],"r");
	ifp=fopen(argv[2],"r");
	ofp=fopen(argv[3],"w");
	for(qCoef=0;qCoef<8;qCoef++)
	{
		for(j1=0;j1<8;j1++)
		{
			fscanf(ifp,"%f",&qt[qCoef][j1]);
		}
	}
	fscanf(fp, "%s", str); // Reading MYDCT from inputfile.dct
	fscanf(fp, "%d %d", &row, &col); // Reading rows and columns from inputfile.dct
	fscanf(fp, "%f", &quantValue); // Reading quantValue from inputfile.dct
	
	output = (int **)malloc(row * sizeof(int *));
	for (i=0; i<col; i++)
		output[i] = (int *)malloc(row * sizeof(int));

	fprintf(ofp, "%s\n", "P5");
	fprintf(ofp, "%d %d\n", row, col);
	fprintf(ofp, "%s\n", "255");
	//Reading DCT file and making 8X8 matrix
	int l;
	int x, y;
	int val;
	for(l= 0 ; l <((row/8)*(col/8)) ;l++){
		int count =0;
		fscanf(fp, "%d %d", &x, &y);

		while(count < 8){
			int k;
			for(k=0;k < 8;k++){
				fscanf(fp, "%d", &val);
				values[count][k] = val;
				values[count][k] = (double)values[count][k];
		                values[count][k]-=127;


			}

			count++;

		}
		
		//IDCT function call after 8*8 matrix is ready
		calIDCT(values,f);
		
		int ro,co;
		int mRow,mCol;
		mRow = y;
		mCol= x;
		for(ro = 0 ; ro < 8; ro++){
			mCol=x;
			for(co = 0 ; co < 8; co++){
				output[mRow][mCol]= f[ro][co];
				mCol++;
			}
			mRow++;

		}

	}

	int ro,co;
	char a;
	
//	Making the final rowXcol matrix
	for(ro= 0 ; ro < col; ro++){
		for(co = 0 ; co < row; co++){
			a = output[ro][co];
			fwrite(&a, 1, 1, ofp);

		}


	}

	fclose(fp);
	fclose(ifp);
	fclose(ofp);
}

//function to evaluate IDCT for 8 x 8 block
void calIDCT(double mat[8][8],int f[8][8])
{
	double idctValue=0.0;
	int i,j,u,v;
	for(i=0;i<8;i++)
	{
		for(j=0;j<8;j++)
		{
			mat[i][j]=(mat[i][j]*qt[i][j])*quantValue;
			

		}
	}
//IDCT matrix is
	for(u=0;u<8;u++)
	{
		for(v=0;v<8;v++)
		{
			idctValue=idct(u,v,mat)/4.0;
			f[u][v]=(int)round(idctValue);
			if(f[u][v]>255)
				f[u][v]=255;
			if(f[u][v]<0)
				f[u][v]=0;

			
		}
//		printf("\n");
	}


}
//The folowing function peforms summations inside IDCT formula
double idct(int u, int v, double mat[8][8])
{
	int i, j;
	double Cu,Cv;
	double matvalue=0.0;
	for(i=0;i<8;i++)
	{
		for(j=0;j<8;j++)
		{
			Cu=1;
			Cv=1;
			if(i==0)
				Cu=(1/sqrt(2));
			if(j==0)
				Cv=(1/sqrt(2));
			matvalue+=Cu*Cv*mat[i][j]*cos((float)((2*u)+1)*i*PI/16.0)*cos((float)((2*v)+1)*j*PI/16.0);
		}
	}
	return(matvalue);
}


